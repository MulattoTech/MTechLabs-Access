# MTerm-CLI ChatGPT private plugin v0.2.1

This archive is **plugin source**, not a Windows installer or a guarantee that ChatGPT can install directly from a file. Its endpoint is `https://mcp.m-techlabs.com/mcp`.

## Configure and recover

1. Open the owner-only manager at https://m-techlabs.com/admin/mcp and use **Plugin & recovery** for the latest archive and status.
2. Open the existing private ChatGPT plugin entry at https://chatgpt.com/plugins/plugins_6aed1a85300481919559498b458ed278.
3. Try connecting/authorizing from ChatGPT if offered, and complete Cloudflare Access OAuth with the owner account.
4. If ChatGPT only offers uninstall, retain this archive first; reinstall or re-create the private plugin using the ChatGPT plugin creation workflow available to your account and this archive. The plugin ID might change if you create a new plugin.
5. Start a new chat with the plugin enabled and request `get_file_info` for `H:\MTechLabs\MCP\runtime\package.json`. Only this call validates the end-to-end ChatGPT path.

Do **not** delete the Windows manager, cloudflared, or the manager's config for a ChatGPT-side auth problem. ChatGPT account installation and consent cannot be reset by an MCP server.

Publishing a newer package on the website is a separate step from updating the private plugin in ChatGPT. See the site's package release synchronization documentation.
