---
name: mterm-connection-recovery
description: Diagnose the private MTerm-CLI ChatGPT connection and open the owner-only manager for configuration or recovering a broken OAuth installation.
---

# Recover MTerm-CLI safely

1. Distinguish backend health, plugin installation in the present ChatGPT conversation, and authenticated MCP tool-call success. A healthy endpoint alone does not establish working ChatGPT authorization.
2. The owner-only management page is https://m-techlabs.com/admin/mcp. The current private plugin is https://chatgpt.com/plugins/plugins_6aed1a85300481919559498b458ed278.
3. The server endpoint is https://mcp.m-techlabs.com/mcp, using OAuth and dynamic client registration. Never paste manager tokens into ChatGPT settings or downloads.
4. Browser-side OAuth consent/install is controlled by ChatGPT and Cloudflare Access; MCP tools cannot create a native ChatGPT Settings Reconnect button or bypass consent.
5. Prefer a reconnect if offered; otherwise download a verified package before uninstalling, reinstall from the supported plugin creation flow, then test get_file_info for H:\MTechLabs\MCP\runtime\package.json.
6. Do not change local services or Cloudflare OAuth to work around a missing ChatGPT-side install.
